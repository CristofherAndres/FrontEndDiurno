import  React, {useState, useEffect, Fragment} from "react";

import './App.css';

const API_URL = "https://api.imgflip.com/get_memes";

function Meme({item}){
    return (
        <div className="col-3">
            <div className="card">
                <img src={item.url} className="card-img-top" alt="Imagen del meme" />
                <div className="card-body">
                    <h5 className="card-title">{item.name}</h5>
                    <a href={item.url} target="_blank" rel="noreferrer"  className="btn btn-primary d-md-block">ver</a>
                </div>
            </div>
        </div>
    );
}

function App() {

    const [items, setItems] = useState([])
    const [error, setError] = useState(null)
    const [isLoaded, setIsLoaded] = useState(false)
    const [searchInput, setSearchInput] = useState('')

    const searchItems = (searchValue) => {
        //console.log(searchValue)
        setSearchInput(searchValue)
    }

    useEffect(() => {
        fetch(API_URL)
            .then(res => res.json())
            .then(
                (result) => {
                    //console.log(result)
                    setIsLoaded(true);
                    setItems(result.data.memes);
                },

                (error) => {
                    setIsLoaded(true);
                    setError(error);
                }
            )
    }, [])

    if (error){
        return <div>Error: {error.message}</div>
    }else if (!isLoaded){
        return <div>Cargando....</div>
    }else{
        return (
            <Fragment>
                <h1 className="alert alert-primary">Memes</h1>

                <div className="input-group mb-5 mt-5">
                    <input onChange={(e) => searchItems(e.target.value)}  className="form-control me-3" type="search" ></input>
                    <button className="btn btn-primary w-25">BUSCAR</button>
                </div>

                <div className="row">
                    {items.filter(item => item.name.toLowerCase().includes(searchInput.toLowerCase())).map(item => (
                        <Meme key={item.id} item={item}/>
                    ))}
                </div>
            </Fragment>
          );
    }
}

export default App;
