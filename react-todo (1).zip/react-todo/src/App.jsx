import React, { Fragment } from 'react'
import { TodoList } from './components/TodoList'

export function App(){
    return (
        <Fragment>
            <TodoList />
        </Fragment>
    )
}
