import React, { Fragment, useState, useRef } from 'react'
import { v4 as uuid } from 'uuid';
import { TodoItem } from './TodoItem';

export function TodoList(){

    const [todos, setTodos] = useState([

    ]);

    const taskRef = useRef();

    const agregarTarea = () => {
        console.log("AGREGANDO TAREA");
        const task = taskRef.current.value;

        if (task === '') return;

        setTodos((prevTodos) => {
            const newTask = {
                id: uuid(),
                task: task
            }

            return [...prevTodos, newTask]
        })

    }

    return (

        <Fragment>
            <h1>Listado de Tareas</h1>

            <div className="input-group mt-4 mb-4">
                <input ref={taskRef} placeholder='Ingrese una tarea' className="form-control" type="text"></input>
                <button onClick={agregarTarea} className="btn btn-success ms-2">+</button>
            </div>

            <ul className="list-group">
                {todos.map((todo) => (
                    <TodoItem todo={todo} key={todo.id}></TodoItem>
                ))}
            </ul>
        </Fragment>

    );
}
